using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.DebuggerVisualizers;
using System.Data;
using System.Runtime.Serialization.Formatters.Binary;

namespace DataSetVisualizer
{
	class DataRowVisualizerObjectSource : VisualizerObjectSource
	{
		public override void GetData(object target, System.IO.Stream outgoingData)
		{
			if(target != null && target is DataRow)
			{
				DataTable tableToBeSerialized;
				DataRow row = target as DataRow;

				if (row.Table == null)
				{
					tableToBeSerialized = new DataTable();
					int inc = 0;
					foreach (object item in row.ItemArray)
					{
						tableToBeSerialized.Columns.Add("Column" + inc++, item.GetType());
					}
				}
				else
				{
					tableToBeSerialized = row.Table.Clone();
				}

				tableToBeSerialized.LoadDataRow(row.ItemArray, true);

				BinaryFormatter formatter = new BinaryFormatter();
				formatter.Serialize(outgoingData, tableToBeSerialized);
			}
			else if (target != null && target is DataRowView)
			{
				DataTable tableToBeSerialized;
				DataRow row = ((DataRowView)target).Row;

				if (row.Table == null)
				{
					tableToBeSerialized = new DataTable();
					int inc = 0;
					foreach (object item in row.ItemArray)
					{
						tableToBeSerialized.Columns.Add("Column" + inc++, item.GetType());
					}
				}
				else
				{
					tableToBeSerialized = row.Table.Clone();
				}

				tableToBeSerialized.LoadDataRow(row.ItemArray, true);

				BinaryFormatter formatter = new BinaryFormatter();
				formatter.Serialize(outgoingData, tableToBeSerialized);
			}
		}
	}
}
