using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.DebuggerVisualizers;
using System.Windows.Forms;
using System.Data;

[assembly: System.Diagnostics.DebuggerVisualizer(
			typeof(DataSetVisualizer.DataTableVisualizer),
			typeof(VisualizerObjectSource),
			Target = typeof(System.Data.DataTable),
			Description = "My Data Table Visualizer")]

namespace DataSetVisualizer
{
	public class DataTableVisualizer : DialogDebuggerVisualizer
	{
		override protected void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider)
		{
			try
			{
				DataTable tempTable = (System.Data.DataTable)objectProvider.GetObject();
				Visualizer myVisualizer = new Visualizer(tempTable);
				windowService.ShowDialog((Form)myVisualizer);
			}
			catch (Exception) { }
		}
	}
}
