using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataSetVisualizer
{
	public partial class Visualizer : Form
	{
		DataView sourceView;
		public Visualizer(DataTable sourceTable)
		{
			InitializeComponent();
			sourceView = sourceTable.DefaultView;
			_dgvOnly.DataSource = sourceTable;
		}

		private void _btnFilter_Click(object sender, EventArgs e)
		{
			sourceView.RowFilter = _txtFilter.Text.Trim();
			_dgvOnly.DataSource = sourceView.ToTable();
		}

		private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				_dgvOnly.SelectAll();
			}
			catch (Exception)
			{
			}
		}

		private void copyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				Clipboard.SetDataObject(_dgvOnly.GetClipboardContent(), true);
			}
			catch (Exception)
			{
			}
		}
	}
}