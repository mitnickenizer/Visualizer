using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataSetVisualizer
{
	public partial class DSVisualizer : Form
	{
		DataSet currentSet;
		DataView currentView;
		public DSVisualizer(DataSet currentSet)
		{
			InitializeComponent();
			this.currentSet = currentSet;
			foreach (DataTable table in currentSet.Tables)
			{
				_tableList.Items.Add(table.TableName);
			}
			if (currentSet.Tables.Count > 0)
			{
				_tableList.SelectedIndex = 0;
				currentView = currentSet.Tables[0].DefaultView;
				_dgvView.DataSource = currentView;
				
			}
		}

		private void _tableList_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				currentView = currentSet.Tables[_tableList.SelectedIndex].DefaultView;
				_dgvView.DataSource = currentView;
			}
			catch (Exception)
			{
			}
		}

		private void _btnFilter_Click(object sender, EventArgs e)
		{
			try
			{
				currentView.RowFilter = _txtFilter.Text;
				_dgvView.DataSource = currentView.ToTable();
			}
			catch (Exception)
			{
			}
		}

		private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				_dgvView.SelectAll();
			}
			catch(Exception)
			{
			}
		}

		private void copyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				Clipboard.SetDataObject(_dgvView.GetClipboardContent(), true);
			}
			catch (Exception)
			{
			}
		}
	}
}