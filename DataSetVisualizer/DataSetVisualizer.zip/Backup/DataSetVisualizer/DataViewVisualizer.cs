using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.DebuggerVisualizers;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

[assembly: System.Diagnostics.DebuggerVisualizer(
			typeof(DataSetVisualizer.DataViewVisualizer),
			typeof(DataSetVisualizer.DataViewVisualizerObjectSource),
			Target = typeof(System.Data.DataView),
			Description = "My Data View Visualizer")]

namespace DataSetVisualizer
{
	public class DataViewVisualizer : DialogDebuggerVisualizer
	{
		override protected void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider)
		{
			try
			{
				DataTable tempTable = (System.Data.DataTable)objectProvider.GetObject();
				Visualizer myVisualizer = new Visualizer(tempTable);
				windowService.ShowDialog((Form)myVisualizer);
			}
			catch (Exception)
			{
				try
				{
					Stream myObjectStream = objectProvider.GetData();
					BinaryFormatter formatter = new BinaryFormatter();
					DataTable tempTable = (System.Data.DataTable)formatter.Deserialize(myObjectStream);
					Visualizer myVisualizer = new Visualizer(tempTable);
					windowService.ShowDialog((Form)myVisualizer);
				}
				catch (Exception)
				{
				}
			}
		}
	}
}