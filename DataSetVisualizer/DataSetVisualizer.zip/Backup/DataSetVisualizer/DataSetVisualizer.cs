using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.DebuggerVisualizers;
using System.Windows.Forms;
using System.Data;

[assembly: System.Diagnostics.DebuggerVisualizer(
			typeof(DataSetVisualizer.DataSetVisualizer),
			typeof(VisualizerObjectSource),
			Target = typeof(System.Data.DataSet),
			Description = "My Data Set Visualizer")]

namespace DataSetVisualizer
{
	public class DataSetVisualizer : DialogDebuggerVisualizer
	{
		override protected void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider)
		{
			DataSet tempSet = (System.Data.DataSet)objectProvider.GetObject();
			DSVisualizer myVisualizer = new DSVisualizer(tempSet);
			windowService.ShowDialog((Form)myVisualizer);
		}
	}
}