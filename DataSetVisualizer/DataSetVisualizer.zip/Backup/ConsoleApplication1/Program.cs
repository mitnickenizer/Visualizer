using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.VisualStudio.DebuggerVisualizers;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			DataTable mine = new DataTable();
			mine.Columns.Add("Test", typeof(string));
			DataRow myRow = mine.NewRow();
			myRow["Test"] = "Hello World";
			mine.Rows.Add(myRow);
			TestShowVisualizer(myRow);
		}

		public static void TestShowVisualizer(object objectToVisualize)
		{
			VisualizerDevelopmentHost myHost = new VisualizerDevelopmentHost(objectToVisualize, typeof(DataSetVisualizer.DataRowVisualizer));
			myHost.ShowVisualizer();
		}
	}
}
