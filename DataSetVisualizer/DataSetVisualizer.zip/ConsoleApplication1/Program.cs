using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.VisualStudio.DebuggerVisualizers;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			DataTable mine = new DataTable();
			mine.Columns.Add("Test", typeof(string));
			DataRow myRow = mine.NewRow();
			myRow["Test"] = "Hello World";
			mine.Rows.Add(myRow);
			myRow = mine.NewRow();
			myRow["Test"] = "I said hello world";
			mine.Rows.Add(myRow);
			mine.AcceptChanges();
			//TestShowVisualizer(mine);
			DataSet myDataset = new DataSet();
			myDataset.Tables.Add(mine);
			TestShowVisualizer(mine);
		}

		public static void TestShowVisualizer(object objectToVisualize)
		{
			VisualizerDevelopmentHost myHost = new VisualizerDevelopmentHost(objectToVisualize, typeof(DataSetVisualizer.DataTableVisualizer));
			myHost.ShowVisualizer();
		}
	}
}
